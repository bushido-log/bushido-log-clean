// App.tsx (refactor / rewrite)
// BUSHIDO LOG - single file version (keeps your current features)

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { WebView } from 'react-native-webview';

// =========================
// Config / Constants
// =========================

const API_BASE = "https://bushido-log-server.onrender.com";
const SAMURAI_TTS_URL = `${API_BASE}/tts`;
const SAMURAI_CHAT_URL = `${API_BASE}/samurai-chat`;
const SAMURAI_MISSION_URL = `${API_BASE}/mission`;

const PRESS_SOUND = require('./sounds/taiko-hit.mp3');

const SESSION_KEY = 'samurai_session_id';

// AsyncStorage Keys
const HISTORY_KEY = 'BUSHIDO_LOG_HISTORY_V1';
const DAILY_LOGS_KEY = 'BUSHIDO_DAILY_LOGS_V1';
const ONBOARDING_KEY = 'BUSHIDO_ONBOARDING_V1';
const XP_KEY = 'BUSHIDO_TOTAL_XP_V1';
const SETTINGS_KEY = 'BUSHIDO_SETTINGS_V1';
const BLOCKLIST_KEY = 'BUSHIDO_BLOCKLIST_V1';
const SAMURAI_TIME_KEY = 'BUSHIDO_SAMURAI_TIME_V1';

const MAX_LEVEL = 10;
const DAYS_PER_LEVEL = 3;

const DEFAULT_ROUTINES = [
  '英語勉強',
  'HIIT 10分',
  'ストレッチ',
  '呼吸 / 瞑想',
  'コールドシャワー',
  'アファメーション',
  '「ありがとう」と言われる行動をする',
  '感謝10個を書く',
  'ジャーナルを書く',
  '自然に触れる（太陽・海・風）',
];

const urgeMessage = 'その欲望、一刀両断！サムライキング参上。';

const PRIVACY_POLICY_TEXT = `
プライバシーポリシー

本プライバシーポリシーは、BUSHIDO LOG（以下「本アプリ」）において、利用者の皆さまの情報をどのように取り扱うかを定めるものです。
本アプリを利用する前に、必ずお読みください。

1. 事業者情報
・アプリ名：BUSHIDO LOG
・運営者名：HIROYA KOSHIISHI
・連絡先：oyaisyours@gmail.com

2. 取得する情報
本アプリでは、次の情報を取得する場合があります。
1. ユーザーが入力するテキスト
・日記・ログ・目標・相談内容などの文章
2. マイクから取得される音声データ
・音声入力で相談した内容
・音声は、AIによる文字起こしのために一時的にサーバーに保存される場合があります。
3. 利用ログ
・利用日時
・どのボタンを押したか など、アプリの改善のための基本的なログ
4. デバイス情報
・OSの種類やバージョン、アプリのバージョン など
※個人を特定することを目的とした情報は取得しません。

3. 情報の利用目的
取得した情報は、主に以下の目的で利用します。
1. AIコーチ機能の提供（チャット・アドバイス・読み上げ等）
2. アプリの品質向上・不具合の調査
3. 利用状況の分析による機能改善
4. 法令への遵守、安全対策のため

4. 外部サービスの利用
本アプリでは、AI機能の提供のため、以下の外部サービスを利用する場合があります。
・OpenAI, L.L.C. が提供する API（テキスト生成・音声合成・文字起こし 等）

AIに送信されるデータには、ユーザーの入力テキストや、音声を文字起こしした内容が含まれる場合があります。
外部サービスの利用にあたっては、各サービスのプライバシーポリシーも合わせてご確認ください。

5. 第三者提供
次の場合を除き、取得した情報を第三者に提供することはありません。
1. ユーザー本人の同意がある場合
2. 法令に基づき開示を求められた場合
3. 人の生命・身体・財産を守るために必要であり、本人の同意を得ることが難しい場合

6. 保存期間
利用ログやテキストデータは、アプリの継続的な利用に必要な範囲で保存します。
不要になった情報は、適切な方法で削除・匿名化します。

7. 安全管理
取得した情報については、不正アクセスや漏えい等を防ぐため、
アクセス権限の管理、通信の暗号化など、合理的な安全対策を行います。

8. 未成年の利用について
本アプリは、13歳以上の利用を想定しています。
未成年の方は、保護者の同意を得た上で利用してください。

9. プライバシーポリシーの変更
本ポリシーの内容は、必要に応じて変更されることがあります。
重要な変更がある場合は、アプリ内でお知らせします。

10. お問い合わせ窓口
本ポリシーに関するお問い合わせは、下記までご連絡ください。
・メールアドレス：oyaisyours@gmail.com
`;

// =========================
// Types
// =========================

type Message = {
  id: string;
  from: 'user' | 'king';
  text: string;
  createdAt?: string;
};

type HistoryEntry = {
  id: string;
  date: string;
  issue: string;
  reflection: string;
  reply: string;
};

type NightReview = {
  proud: string;
  lesson: string;
  nextAction: string;
};

type TodoItem = {
  id: string;
  text: string;
  done: boolean;
};

type DailyLog = {
  date: string;
  mission: string;
  routines: string[];
  todos: TodoItem[];
  review?: NightReview;
  samuraiMission?: string;
  missionCompleted?: boolean;
  routineDone?: string[];
};

type OnboardingData = {
  identity: string;
  quit: string;
  rule: string;
};

type AppSettings = {
  autoVoice: boolean;
  readingSpeed: 'slow' | 'normal' | 'fast';
  enableHaptics: boolean;
  enableSfx: boolean;
  strictness: 'soft' | 'normal' | 'hard';
};

type SamuraiTimeState = {
  date: string;
  seconds: number;
  dailyMinutes: number; // 0 = 無制限
};

// =========================
// Defaults
// =========================

const DEFAULT_SETTINGS: AppSettings = {
  autoVoice: true,
  readingSpeed: 'normal',
  enableHaptics: true,
  enableSfx: true,
  strictness: 'normal',
};

// =========================
// Utils
// =========================

function getTodayStr() {
  return new Date().toISOString().slice(0, 10);
}
function formatDateLabel(dateStr: string) {
  return dateStr.slice(5);
}
function daysDiff(a: string, b: string) {
  const da = new Date(a);
  const db = new Date(b);
  return Math.round((da.getTime() - db.getTime()) / (1000 * 60 * 60 * 24));
}

function getStreakCount(logs: DailyLog[]): number {
  if (!logs || logs.length === 0) return 0;
  const sorted = [...logs].sort((x, y) => x.date.localeCompare(y.date));
  let streak = 1;
  for (let i = sorted.length - 1; i > 0; i--) {
    const today = sorted[i].date;
    const prev = sorted[i - 1].date;
    if (daysDiff(today, prev) === 1) streak++;
    else break;
  }
  return streak;
}

function getRankFromXp(xp: number) {
  if (xp < 30) return { label: '見習い侍', next: 30 - xp };
  if (xp < 100) return { label: '一人前侍', next: 100 - xp };
  if (xp < 300) return { label: '修羅の侍', next: 300 - xp };
  return { label: '伝説の侍', next: 0 };
}

function getSamuraiLevelInfo(streak: number) {
  if (streak <= 0) {
    return { level: 1, progress: 0, daysToClear: MAX_LEVEL * DAYS_PER_LEVEL };
  }
  const rawLevel = Math.floor((streak - 1) / DAYS_PER_LEVEL) + 1;
  const level = Math.min(MAX_LEVEL, Math.max(1, rawLevel));
  const currentLevelStartDay = (level - 1) * DAYS_PER_LEVEL + 1;
  const daysInThisLevel = streak - currentLevelStartDay + 1;
  const progress = Math.max(0, Math.min(1, daysInThisLevel / DAYS_PER_LEVEL));
  const totalDaysForClear = MAX_LEVEL * DAYS_PER_LEVEL;
  const daysToClear = Math.max(0, totalDaysForClear - streak);
  return { level, progress, daysToClear };
}

async function getSessionId(): Promise<string> {
  let id = await AsyncStorage.getItem(SESSION_KEY);
  if (!id) {
    id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    await AsyncStorage.setItem(SESSION_KEY, id);
  }
  return id;
}

// =========================
// Audio helpers
// =========================

async function playSound(source: any) {
  try {
    const { sound } = await Audio.Sound.createAsync(source);
    await sound.playAsync();
    sound.setOnPlaybackStatusUpdate((status: any) => {
      if (status.isLoaded && status.didJustFinish) {
        sound.unloadAsync();
      }
    });
  } catch (e) {
    console.log('sound error', e);
  }
}

async function playPressSound() {
  await playSound(PRESS_SOUND);
}

// =========================
// API
// =========================

async function callSamuraiKing(message: string): Promise<string> {
  const sessionId = await getSessionId();

  const res = await fetch(SAMURAI_CHAT_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: message, sessionId }),
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.log('SamuraiKing server error body:', errorText);
    throw new Error('Server error');
  }

  const data = await res.json();
return data.reply || data.text || data.message || '（返答が空だったでござる）';
}

async function callSamuraiMissionGPT(): Promise<string> {
  const res = await fetch(SAMURAI_MISSION_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ todayStr: getTodayStr() }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.log('SamuraiMission error body:', text);
    throw new Error('Mission server error');
  }

  const data: { mission?: string; text?: string; reply?: string } = await res.json();
  return (
    data.mission ||
    data.text ||
    data.reply ||
    '今日は「スマホ時間を30分減らして、その分だけ自分の未来のために動く」でいこう。'
  );
}

// =========================
// UI: Samurai Avatar
// =========================

function SamuraiAvatar({ level, rankLabel }: { level: number; rankLabel: string }) {
  let emoji = '🥚';
  let title = `Lv.${level} 見習い侍`;
  let desc = 'まずはブシログを開き続ける段階だな。';

  if (level >= 3 && level <= 6) {
    emoji = '⚔️';
    title = `Lv.${level} 若侍`;
    desc = '習慣が少しずつ形になってきたゾーンだ。油断せず粘っていこう。';
  } else if (level >= 7 && level < MAX_LEVEL) {
    emoji = '🐉';
    title = `Lv.${level} 修羅の侍`;
    desc = 'かなりの継続力だ。周りからも変化が見え始めているはずだぞ。';
  } else if (level >= MAX_LEVEL) {
    emoji = '👑';
    title = `Lv.${level} 伝説の侍`;
    desc = '1ヶ月以上やり切った、本物のサムライだ。ここからは守りではなく拡張だな。';
  }

  return (
    <View style={styles.avatarCard}>
      <View style={styles.avatarCircle}>
        <Text style={styles.avatarEmoji}>{emoji}</Text>
      </View>
      <View style={styles.avatarInfo}>
        <Text style={styles.avatarTitle}>{title}</Text>
        <Text style={styles.avatarRank}>ランク：{rankLabel}</Text>
        <Text style={styles.avatarDesc}>{desc}</Text>
      </View>
    </View>
  );
}

// =========================
// Main App
// =========================

export default function App() {
  const todayStr = useMemo(() => getTodayStr(), []);
  const messagesRef = useRef<ScrollView | null>(null);

  const [tab, setTab] = useState<'consult' | 'goal' | 'review' | 'settings' | 'browser'>('consult');

  // onboarding
  const [isOnboarding, setIsOnboarding] = useState(true);
  const [isLoadingOnboarding, setIsLoadingOnboarding] = useState(true);
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [isEditingOnboarding, setIsEditingOnboarding] = useState(false);
  const [obIdentity, setObIdentity] = useState('');
  const [obQuit, setObQuit] = useState('');
  const [obRule, setObRule] = useState('');

  // settings
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [showPrivacy, setShowPrivacy] = useState(false);

  // chat
  const [isSummoned, setIsSummoned] = useState(false);
  const [mode, setMode] = useState<'chat' | 'history'>('chat');
  const [messages, setMessages] = useState<Message[]>([
    { id: 'first', from: 'king', text: 'おいおいどうした？その欲望を断ち切るぞ。' },
  ]);
  const [input, setInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  // history
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  // daily logs
  const [dailyLogs, setDailyLogs] = useState<DailyLog[]>([]);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  // edit existing review
  const [editingLogDate, setEditingLogDate] = useState<string | null>(null);
  const [editProud, setEditProud] = useState('');
  const [editLesson, setEditLesson] = useState('');
  const [editNextAction, setEditNextAction] = useState('');

  // goal tab inputs
  const [missionInput, setMissionInput] = useState('');
  const [routineText, setRoutineText] = useState('');
  const [todoInput, setTodoInput] = useState('');

  // review tab inputs
  const [proudInput, setProudInput] = useState('');
  const [lessonInput, setLessonInput] = useState('');
  const [nextActionInput, setNextActionInput] = useState('');

  // samurai mission
  const [samuraiMissionText, setSamuraiMissionText] = useState('');
  const [isGeneratingMission, setIsGeneratingMission] = useState(false);
  const [missionCompletedToday, setMissionCompletedToday] = useState(false);

  // XP
  const [totalXp, setTotalXp] = useState(0);

  // browser
  const [browserUrl, setBrowserUrl] = useState('https://google.com');
  const [currentUrl, setCurrentUrl] = useState('https://google.com');
  const [blockedDomains, setBlockedDomains] = useState<string[]>([]);
  const [blocklistInput, setBlocklistInput] = useState('');

  // samurai time
  const [samuraiTime, setSamuraiTime] = useState<SamuraiTimeState>({
    date: todayStr,
    seconds: 0,
    dailyMinutes: 60,
  });

  const isTimeLimited = samuraiTime.dailyMinutes > 0;
  const maxSeconds = samuraiTime.dailyMinutes * 60;
  const isTimeOver = isTimeLimited && samuraiTime.seconds >= maxSeconds;
  const usedMinutes = Math.floor(samuraiTime.seconds / 60);
  const remainingMinutes = isTimeLimited ? Math.max(0, samuraiTime.dailyMinutes - usedMinutes) : null;

  // =========================
  // Startup sound
  // =========================
  useEffect(() => {
    (async () => {
      try {
        const { sound } = await Audio.Sound.createAsync(PRESS_SOUND);
        await sound.playAsync();
        sound.setOnPlaybackStatusUpdate((status: any) => {
          if (status.isLoaded && status.didJustFinish) sound.unloadAsync();
        });
      } catch (e) {
        console.log('start sound error', e);
      }
    })();
  }, []);

  // =========================
  // Keyboard watcher
  // =========================
  useEffect(() => {
    const showSub = Keyboard.addListener('keyboardDidShow', () => setIsKeyboardVisible(true));
    const hideSub = Keyboard.addListener('keyboardDidHide', () => setIsKeyboardVisible(false));
    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  // =========================
  // Loaders
  // =========================

  const loadHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const json = await AsyncStorage.getItem(HISTORY_KEY);
      const logs: HistoryEntry[] = json ? JSON.parse(json) : [];
      setHistory(Array.isArray(logs) ? logs : []);
    } catch (e) {
      console.error('Failed to load history', e);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const json = await AsyncStorage.getItem(DAILY_LOGS_KEY);
        const logs: DailyLog[] = json ? JSON.parse(json) : [];
        setDailyLogs(Array.isArray(logs) ? logs : []);
      } catch (e) {
        console.error('Failed to load daily logs', e);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const json = await AsyncStorage.getItem(ONBOARDING_KEY);
        if (json) {
          const data: OnboardingData = JSON.parse(json);
          setOnboardingData(data);
          setObIdentity(data.identity ?? '');
          setObQuit(data.quit ?? '');
          setObRule(data.rule ?? '');
          setIsOnboarding(false);
        } else {
          setIsOnboarding(true);
        }
      } catch (e) {
        console.error('Failed to load onboarding', e);
      } finally {
        setIsLoadingOnboarding(false);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(XP_KEY);
        if (saved) {
          const num = Number(saved);
          if (!Number.isNaN(num)) setTotalXp(num);
        }
      } catch (e) {
        console.error('Failed to load XP', e);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const json = await AsyncStorage.getItem(SETTINGS_KEY);
        if (json) {
          const parsed: AppSettings = JSON.parse(json);
          setSettings(prev => ({ ...prev, ...parsed }));
        }
      } catch (e) {
        console.error('Failed to load settings', e);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const json = await AsyncStorage.getItem(BLOCKLIST_KEY);
        if (json) {
          const arr = JSON.parse(json);
          if (Array.isArray(arr)) setBlockedDomains(arr);
        }
      } catch (e) {
        console.error('Failed to load blocklist', e);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const json = await AsyncStorage.getItem(SAMURAI_TIME_KEY);
        if (json) {
          const parsed = JSON.parse(json) as SamuraiTimeState;
          if (
            parsed &&
            typeof parsed.dailyMinutes === 'number' &&
            typeof parsed.seconds === 'number' &&
            typeof parsed.date === 'string'
          ) {
            const today = getTodayStr();
            if (parsed.date !== today) {
              setSamuraiTime({ date: today, seconds: 0, dailyMinutes: parsed.dailyMinutes });
            } else {
              setSamuraiTime(parsed);
            }
          }
        }
      } catch (e) {
        console.error('Failed to load samurai time', e);
      }
    })();
  }, []);

  // =========================
  // Tab change sync (Goal/Review)
  // =========================
  useEffect(() => {
    const todayLog = dailyLogs.find(l => l.date === getTodayStr());

    if (tab === 'goal') {
      setMissionInput(todayLog?.mission ?? '');
      setRoutineText(todayLog?.routines?.join('\n') ?? '');
      setTodoInput(todayLog?.todos?.map(t => t.text).join('\n') ?? '');
      setSamuraiMissionText(todayLog?.samuraiMission ?? '');
      setMissionCompletedToday(todayLog?.missionCompleted ?? false);
    }

    if (tab === 'review') {
      const targetDate = selectedDate || (todayLog ? todayLog.date : undefined);
      const targetLog = targetDate ? dailyLogs.find(l => l.date === targetDate) : undefined;

      setProudInput(targetLog?.review?.proud ?? '');
      setLessonInput(targetLog?.review?.lesson ?? '');
      setNextActionInput(targetLog?.review?.nextAction ?? '');

      if (!selectedDate && todayLog) setSelectedDate(todayLog.date);
    }
  }, [tab, dailyLogs, selectedDate]);

  // =========================
  // Auto scroll chat
  // =========================
  useEffect(() => {
    if (mode !== 'chat') return;
    setTimeout(() => messagesRef.current?.scrollToEnd({ animated: true }), 50);
  }, [messages, mode, isKeyboardVisible]);

  // =========================
  // Samurai time ticker
  // =========================
  useEffect(() => {
    if (isOnboarding) return;
    if (!samuraiTime.dailyMinutes || samuraiTime.dailyMinutes <= 0) return;

    let cancelled = false;
    const interval = setInterval(() => {
      if (cancelled) return;

      setSamuraiTime(prev => {
        const today = getTodayStr();
        let base = prev;

        if (prev.date !== today) {
          base = { ...prev, date: today, seconds: 0 };
        }

        const maxSec = base.dailyMinutes * 60;
        if (base.seconds >= maxSec) return base;

        const updated: SamuraiTimeState = { ...base, seconds: base.seconds + 1 };
        AsyncStorage.setItem(SAMURAI_TIME_KEY, JSON.stringify(updated)).catch(() => {});
        return updated;
      });
    }, 1000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [isOnboarding, samuraiTime.dailyMinutes]);

  // =========================
  // Settings save
  // =========================
  const updateSettings = async (patch: Partial<AppSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    try {
      await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  };

  const updateSamuraiDailyMinutes = (text: string) => {
    const numeric = text.replace(/[^0-9]/g, '');
    const num = parseInt(numeric, 10);
    const minutes = Number.isNaN(num) ? 0 : Math.max(0, Math.min(600, num)); // max 10h

    setSamuraiTime(prev => {
      const next: SamuraiTimeState = { ...prev, dailyMinutes: minutes };
      AsyncStorage.setItem(SAMURAI_TIME_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  };

  // =========================
  // Storage helpers: daily logs
  // =========================
  const saveDailyLogsToStorage = async (logs: DailyLog[]) => {
    try {
      await AsyncStorage.setItem(DAILY_LOGS_KEY, JSON.stringify(logs));
    } catch (e) {
      console.error('Failed to save daily logs', e);
    }
  };

  const upsertLogForDate = async (date: string, updater: (prev: DailyLog | undefined) => DailyLog) => {
    const prev = dailyLogs.find(l => l.date === date);
    const updated = updater(prev);
    const others = dailyLogs.filter(l => l.date !== date);
    const newLogs = [...others, updated].sort((a, b) => a.date.localeCompare(b.date));
    setDailyLogs(newLogs);
    await saveDailyLogsToStorage(newLogs);
  };

  const upsertTodayLog = async (updater: (prev: DailyLog | undefined) => DailyLog) => {
    return upsertLogForDate(getTodayStr(), updater);
  };

  // =========================
  // TTS (server audio)
  // =========================
  const speakSamurai = async (text: string) => {
    if (!text || !settings.autoVoice) return;

    const url = `${SAMURAI_TTS_URL}?text=${encodeURIComponent(text)}`;
    try {
      const { sound } = await Audio.Sound.createAsync({ uri: url });
      await sound.playAsync();
      sound.setOnPlaybackStatusUpdate((status: any) => {
        if (status.isLoaded && status.didJustFinish) sound.unloadAsync();
      });
    } catch (e) {
      console.log('[TTS] error', e);
    }
  };

  // =========================
  // Haptics/SFX wrappers
  // =========================
  const tap = async (type: 'light' | 'medium' | 'select' | 'success' = 'select') => {
    if (!settings.enableHaptics && !settings.enableSfx) return;

    if (settings.enableHaptics) {
      if (type === 'light') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
      if (type === 'medium') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
      if (type === 'select') Haptics.selectionAsync().catch(() => {});
      if (type === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    }
    if (settings.enableSfx) await playPressSound();
  };

  // =========================
  // Chat actions
  // =========================
  const handleUrgePress = async () => {
    setIsSummoned(true);
    await tap('medium');
    speakSamurai(urgeMessage);
  };

  const handleSend = async () => {
    if (!input.trim() || isSending) return;

    await tap('select');

    const userText = input.trim();
    setInput('');
    setIsSending(true);

    const userMsg: Message = {
      id: `${Date.now()}`,
      from: 'user',
      text: userText,
      createdAt: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      const replyText = await callSamuraiKing(userText);

      const kingMsg: Message = {
        id: `${Date.now()}-samurai`,
        from: 'king',
        text: replyText,
        createdAt: new Date().toISOString(),
      };
      setMessages(prev => [...prev, kingMsg]);
      speakSamurai(replyText);

      const entry: HistoryEntry = {
        id: `${Date.now()}`,
        date: new Date().toISOString(),
        issue: userText,
        reflection: '',
        reply: replyText,
      };
      const updatedHistory = [...history, entry];
      setHistory(updatedHistory);
      await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
    } catch (error) {
      console.log('SamuraiKing error', error);
      setMessages(prev => [
        ...prev,
        {
          id: `${Date.now()}-error`,
          from: 'king',
          text: 'ネットワークエラーでござる。もう一度試してほしいでござる。',
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleSwitchToChat = async () => {
    await tap('select');
    setMode('chat');
  };

  const handleSwitchToHistory = async () => {
    await tap('select');
    setMode('history');
    await loadHistory();
  };

  // =========================
  // Daily log actions (goal/review)
  // =========================

  const handleSaveTodayMission = async () => {
    await tap('light');

    await upsertTodayLog(prev => {
      const prevTodos = prev?.todos ?? [];
      const todoLines = todoInput
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);

      const todos: TodoItem[] = todoLines.map((text, index) => {
        const existing = prevTodos.find(t => t.text === text);
        return existing ?? { id: `${getTodayStr()}-${index}`, text, done: false };
      });

      const routineLines = routineText
        .split('\n')
        .map(l => l.trim())
        .filter(Boolean);

      const prevDone = prev?.routineDone ?? [];
      const newRoutineDone = prevDone.filter(r => routineLines.includes(r));

      return {
        date: getTodayStr(),
        mission: missionInput.trim(),
        routines: routineLines,
        todos,
        review: prev?.review,
        samuraiMission: prev?.samuraiMission,
        missionCompleted: prev?.missionCompleted ?? false,
        routineDone: newRoutineDone,
      };
    });
  };

  const handleSaveNightReview = async () => {
    await tap('light');

    const targetDate = selectedDate || getTodayStr();

    await upsertLogForDate(targetDate, prev => ({
      date: targetDate,
      mission: prev?.mission ?? '',
      routines: prev?.routines ?? [],
      todos: prev?.todos ?? [],
      review: {
        proud: proudInput.trim(),
        lesson: lessonInput.trim(),
        nextAction: nextActionInput.trim(),
      },
      samuraiMission: prev?.samuraiMission,
      missionCompleted: prev?.missionCompleted ?? false,
      routineDone: prev?.routineDone ?? [],
    }));
  };

  const toggleTodoDone = async (date: string, todoId: string) => {
    await tap('select');

    const newLogs = dailyLogs.map(log => {
      if (log.date !== date) return log;
      return {
        ...log,
        todos: log.todos.map(t => (t.id === todoId ? { ...t, done: !t.done } : t)),
      };
    });

    setDailyLogs(newLogs);
    await saveDailyLogsToStorage(newLogs);
  };

  const toggleRoutineDone = async (date: string, label: string) => {
    await tap('select');

    const newLogs = dailyLogs.map(log => {
      if (log.date !== date) return log;
      const prevDone = log.routineDone ?? [];
      const exists = prevDone.includes(label);
      const updatedDone = exists ? prevDone.filter(r => r !== label) : [...prevDone, label];
      return { ...log, routineDone: updatedDone };
    });

    setDailyLogs(newLogs);
    await saveDailyLogsToStorage(newLogs);
  };

  const handleGenerateSamuraiMission = async () => {
    if (isGeneratingMission) return;

    await tap('medium');

    setIsGeneratingMission(true);
    try {
      const mission = await callSamuraiMissionGPT();
      setSamuraiMissionText(mission);

      await upsertTodayLog(prev => ({
        date: getTodayStr(),
        mission: prev?.mission ?? missionInput.trim(),
        routines: prev?.routines ?? [],
        todos: prev?.todos ?? [],
        review: prev?.review,
        samuraiMission: mission,
        missionCompleted: prev?.missionCompleted ?? false,
        routineDone: prev?.routineDone ?? [],
      }));
    } catch (e) {
      console.error(e);
      setMessages(prev => [
        ...prev,
        {
          id: `${Date.now()}-mission-err`,
          from: 'king',
          text: 'サムライミッション生成でエラーが出たでござる。ネット環境とサーバーを確認してほしいでござる。',
        },
      ]);
    } finally {
      setIsGeneratingMission(false);
    }
  };

  const handleCompleteSamuraiMission = async () => {
    if (!samuraiMissionText || missionCompletedToday) return;

    await tap('success');

    const gainedXp = 10;
    const newXp = totalXp + gainedXp;
    setTotalXp(newXp);
    await AsyncStorage.setItem(XP_KEY, String(newXp));

    setMissionCompletedToday(true);

    await upsertTodayLog(prev => ({
      date: getTodayStr(),
      mission: prev?.mission ?? missionInput.trim(),
      routines: prev?.routines ?? [],
      todos: prev?.todos ?? [],
      review: prev?.review,
      samuraiMission: samuraiMissionText,
      missionCompleted: true,
      routineDone: prev?.routineDone ?? [],
    }));

    const praiseText = `よくやった。今日のサムライミッション「${samuraiMissionText}」は達成だ。\n10XP獲得でござる。`;
    setMessages(prev => [...prev, { id: `${Date.now()}-xp`, from: 'king', text: praiseText }]);
    speakSamurai(praiseText);
  };

  // =========================
  // Onboarding save
  // =========================
  const handleSaveOnboarding = async () => {
    const identity = obIdentity.trim();
    const quit = obQuit.trim();
    const rule = obRule.trim();
    if (!identity) return;

    await tap('light');

    const data: OnboardingData = { identity, quit, rule };
    try {
      await AsyncStorage.setItem(ONBOARDING_KEY, JSON.stringify(data));
      setOnboardingData(data);
      setIsEditingOnboarding(false);
      setIsOnboarding(false);
    } catch (e) {
      console.error('Failed to save onboarding', e);
    }
  };

  // =========================
  // Blocklist actions
  // =========================
  const handleAddBlockDomain = async () => {
    const value = blocklistInput.trim();
    if (!value) return;

    const normalized = value.replace(/^https?:\/\//, '').replace(/\/.*$/, '').toLowerCase();
    const newList = Array.from(new Set([...blockedDomains, normalized]));

    setBlockedDomains(newList);
    setBlocklistInput('');
    try {
      await AsyncStorage.setItem(BLOCKLIST_KEY, JSON.stringify(newList));
    } catch (e) {
      console.error('Failed to save blocklist', e);
    }
  };

  const handleRemoveBlockDomain = async (domain: string) => {
    const newList = blockedDomains.filter(d => d !== domain);
    setBlockedDomains(newList);
    try {
      await AsyncStorage.setItem(BLOCKLIST_KEY, JSON.stringify(newList));
    } catch (e) {
      console.error('Failed to save blocklist', e);
    }
  };

  const handleOpenBrowserUrl = async () => {
    let url = browserUrl.trim();
    if (!url) return;
    if (!/^https?:\/\//.test(url)) url = 'https://' + url;

    setBrowserUrl(url);
    setCurrentUrl(url);
    if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
  };

  // =========================
  // Reset actions
  // =========================
  const handleClearHistory = () => {
    Alert.alert('相談履歴を削除', 'これまでのサムライ相談の履歴をすべて消すでござる。よろしいか？', [
      { text: 'キャンセル', style: 'cancel' },
      {
        text: '削除する',
        style: 'destructive',
        onPress: async () => {
          try {
            await AsyncStorage.removeItem(HISTORY_KEY);
            setHistory([]);
          } catch (e) {
            console.error('Failed to clear history', e);
          }
        },
      },
    ]);
  };

  const handleClearChatMessages = () => {
    Alert.alert('チャット画面をリセット', '会話バブルを全部消して、最初の一言だけに戻すでござる。よろしいか？', [
      { text: 'キャンセル', style: 'cancel' },
      {
        text: 'リセットする',
        style: 'destructive',
        onPress: () => {
          setMessages([{ id: 'first', from: 'king', text: 'おいおいどうした？その欲望を断ち切るぞ。' }]);
          setInput('');
          setIsSending(false);
        },
      },
    ]);
  };

  const handleResetTodayLog = () => {
    Alert.alert('今日の目標・日記をリセット', `${getTodayStr()} の目標・ルーティン・振り返りを消すでござる。よろしいか？`, [
      { text: 'キャンセル', style: 'cancel' },
      {
        text: 'リセットする',
        style: 'destructive',
        onPress: async () => {
          try {
            const t = getTodayStr();
            const newLogs = dailyLogs.filter(log => log.date !== t);
            setDailyLogs(newLogs);
            await saveDailyLogsToStorage(newLogs);

            setMissionInput('');
            setRoutineText('');
            setTodoInput('');
            setProudInput('');
            setLessonInput('');
            setNextActionInput('');
            setSamuraiMissionText('');
            setMissionCompletedToday(false);
          } catch (e) {
            console.error('Failed to reset today log', e);
          }
        },
      },
    ]);
  };

  // =========================
  // Calendar edit actions
  // =========================
  const handleEditLogFromCalendar = (log: DailyLog) => {
    setEditingLogDate(log.date);
    setEditProud(log.review?.proud ?? '');
    setEditLesson(log.review?.lesson ?? '');
    setEditNextAction(log.review?.nextAction ?? '');
  };

  const handleSaveEditedLog = async () => {
    if (!editingLogDate) return;

    const newLogs = dailyLogs.map(log =>
      log.date === editingLogDate
        ? {
            ...log,
            review: { proud: editProud, lesson: editLesson, nextAction: editNextAction },
          }
        : log,
    );

    setDailyLogs(newLogs);
    await saveDailyLogsToStorage(newLogs);

    setEditingLogDate(null);
    setEditProud('');
    setEditLesson('');
    setEditNextAction('');
  };

  const handleDeleteLog = async (date: string) => {
    const newLogs = dailyLogs.filter(log => log.date !== date);
    setDailyLogs(newLogs);
    await saveDailyLogsToStorage(newLogs);

    if (selectedDate === date) setSelectedDate(null);
  };

  // =========================
  // Routine chip toggle
  // =========================
  const handleToggleRoutineChip = (label: string) => {
    if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
    const lines = routineText.split('\n').map(l => l.trim()).filter(Boolean);
    const exists = lines.includes(label);
    const newLines = exists ? lines.filter(l => l !== label) : [...lines, label];
    setRoutineText(newLines.join('\n'));
  };

  // =========================
  // Derived values
  // =========================
  const sortedDailyLogs: DailyLog[] = useMemo(() => {
    return Array.isArray(dailyLogs) ? [...dailyLogs].sort((a, b) => a.date.localeCompare(b.date)) : [];
  }, [dailyLogs]);

  const streakCount = useMemo(() => getStreakCount(sortedDailyLogs), [sortedDailyLogs]);
  const { level: samuraiLevel, progress: levelProgress, daysToClear } = useMemo(
    () => getSamuraiLevelInfo(streakCount),
    [streakCount],
  );
  const rank = useMemo(() => getRankFromXp(totalXp), [totalXp]);

  const activeDate = useMemo(() => {
    return (
      selectedDate ||
      (sortedDailyLogs.length ? sortedDailyLogs[sortedDailyLogs.length - 1].date : null)
    );
  }, [selectedDate, sortedDailyLogs]);

  const activeLog = useMemo(() => {
    return activeDate ? sortedDailyLogs.find(log => log.date === activeDate) : null;
  }, [activeDate, sortedDailyLogs]);

  // =========================
  // Render helpers
  // =========================
  const renderTabButton = (value: typeof tab, label: string) => (
    <Pressable
      onPress={() => {
        if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
        setTab(value);
      }}
      style={[styles.tabButton, tab === value && styles.tabButtonActive]}
    >
      <Text style={[styles.tabButtonText, tab === value && styles.tabButtonTextActive]}>{label}</Text>
    </Pressable>
  );

  // =========================
  // Tabs
  // =========================

  const renderConsultTab = () => {
    const historyToShow = history.length > 50 ? history.slice(history.length - 50) : history;

    return (
      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: 24 }} 
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={true}
        bounces={true}
      >
        <Pressable style={styles.urgeButton} onPress={handleUrgePress}>
          <Text style={styles.urgeText}>サムライキングを呼び出す</Text>
        </Pressable>
        <Text style={styles.caption}>ムラムラ・不安・サボりたくなったら、このボタンを押して本音を打ち込むのだ。</Text>

        {!isSummoned ? (
          <View style={styles.summonBox}>
            <Text style={styles.summonTitle}>Samurai King is waiting…</Text>
            <Text style={styles.summonText}>
              サムライキングは静かにお主を待っている。{'\n'}
              呼び出したあと「チャット」で本音を書いていくのだ。
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.modeRow}>
              <Pressable style={[styles.modeButton, mode === 'chat' && styles.modeButtonActive]} onPress={handleSwitchToChat}>
                <Text style={[styles.modeButtonText, mode === 'chat' && styles.modeButtonTextActive]}>チャット</Text>
              </Pressable>

              <Pressable
                style={[styles.modeButton, mode === 'history' && styles.modeButtonActive, { marginRight: 0, marginLeft: 4 }]}
                onPress={handleSwitchToHistory}
              >
                <Text style={[styles.modeButtonText, mode === 'history' && styles.modeButtonTextActive]}>履歴</Text>
              </Pressable>
            </View>

            <View style={styles.chatBox}>
              {mode === 'chat' ? (
                <>
                  <Text style={styles.chatTitle}>Samurai King Chat</Text>

                  <ScrollView
                    ref={messagesRef}
                    style={[styles.messages, { maxHeight: 320 }]}
                    contentContainerStyle={{ paddingBottom: 16 }}
                    keyboardShouldPersistTaps="handled"
                    nestedScrollEnabled={true}
                    showsVerticalScrollIndicator={true}
                    bounces={true}
                    onContentSizeChange={() => messagesRef.current?.scrollToEnd({ animated: true })}
                  >
                    {messages.map(m => (
                      <View key={m.id} style={[styles.bubble, m.from === 'user' ? styles.userBubble : styles.kingBubble]}>
                        <Text style={styles.bubbleLabel}>{m.from === 'user' ? 'You' : 'Samurai King'}</Text>
                        <Text style={styles.bubbleText}>{m.text}</Text>
                      </View>
                    ))}
                  </ScrollView>

                  <View style={styles.inputRow}>
                    <TextInput
                      style={styles.input}
                      value={input}
                      onChangeText={setInput}
                      placeholder="今のムラムラや悩みを正直に書くのだ…"
                      placeholderTextColor="#666"
                      multiline
                      blurOnSubmit
                      returnKeyType="done"
                      onSubmitEditing={handleSend}
                    />
                    <Pressable
                      style={[styles.sendButton, !input.trim() && { opacity: 0.5 }]}
                      onPress={handleSend}
                      disabled={!input.trim() || isSending}
                    >
                      {isSending ? <ActivityIndicator color="#022c22" /> : <Text style={styles.sendText}>送信</Text>}
                    </Pressable>
                  </View>

                  <Text style={styles.privacyNote}>
                    ※ 相談内容はこのスマホとサムライキングAIだけに使われる。{'\n'}
                    開発者本人が個別の相談内容を見ることはないでござる。
                  </Text>

                  <Pressable style={styles.secondaryButton} onPress={handleClearChatMessages}>
                    <Text style={styles.secondaryButtonText}>チャット画面をリセット</Text>
                  </Pressable>
                </>
              ) : (
                <>
                  <Text style={styles.chatTitle}>Samurai Log History</Text>

                  {isLoadingHistory ? (
                    <Text style={styles.historyInfo}>履歴を読み込み中でござる…</Text>
                  ) : historyToShow.length === 0 ? (
                    <Text style={styles.historyInfo}>まだ記録はないでござる。最初の相談をすると自動でここにたまっていくでござる。</Text>
                  ) : (
                    <>
                      {historyToShow
                        .slice(-50)
                        .reverse()
                        .map(entry => {
                          let dateLabel = '';
                          try {
                            const d = new Date(entry.date);
                            dateLabel = Number.isNaN(d.getTime()) ? '' : d.toLocaleString();
                          } catch {
                            dateLabel = '';
                          }

                          return (
                            <View key={entry.id} style={styles.historyEntry}>
                              {dateLabel !== '' && <Text style={styles.historyDate}>{dateLabel}</Text>}

                              <Text style={styles.historyLabel}>◆ 相談：</Text>
                              <Text style={styles.historyText}>{entry.issue}</Text>

                              <Text style={styles.historyLabel}>◆ 本当はこうなりたい：</Text>
                              <Text style={styles.historyText}>
                                {entry.reflection && entry.reflection.trim() !== '' ? entry.reflection : '（未記入）'}
                              </Text>

                              <Text style={styles.historyLabel}>◆ サムライキング：</Text>
                              <Text style={styles.historyText}>{entry.reply}</Text>
                            </View>
                          );
                        })}

                      <Pressable style={styles.secondaryButton} onPress={handleClearHistory}>
                        <Text style={styles.secondaryButtonText}>相談履歴を全部削除</Text>
                      </Pressable>
                    </>
                  )}
                </>
              )}
            </View>
          </>
        )}
      </ScrollView>
    );
  };

  const renderGoalTab = () => {
    const currentRoutineLines = routineText.split('\n').map(l => l.trim()).filter(Boolean);

    return (
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={styles.goalCard}>
          <Text style={styles.goalTitle}>今日のサムライ目標</Text>
          <Text style={styles.goalSub}>{getTodayStr()} のミッションを 1つだけ決めるのだ。</Text>

          <View style={{ marginBottom: 12 }}>
            <View style={styles.samuraiMissionHeaderRow}>
              <Text style={styles.samuraiMissionTitle}>サムライミッション</Text>
              <Text style={styles.samuraiMissionXp}>達成で 10XP</Text>
            </View>
            <Text style={styles.goalSub}>AIが「今日やるといい一手」をくれるでござる。</Text>

            {samuraiMissionText ? (
              <View style={styles.samuraiMissionBox}>
                <Text style={styles.samuraiMissionText}>{samuraiMissionText}</Text>
                <Pressable
                  style={[styles.samuraiMissionButton, missionCompletedToday && { opacity: 0.5 }]}
                  onPress={handleCompleteSamuraiMission}
                  disabled={missionCompletedToday}
                >
                  <Text style={styles.samuraiMissionButtonText}>
                    {missionCompletedToday ? '達成済み！' : 'ミッション達成！XPゲット'}
                  </Text>
                </Pressable>
              </View>
            ) : (
              <Pressable style={styles.samuraiMissionButton} onPress={handleGenerateSamuraiMission}>
                <Text style={styles.samuraiMissionButtonText}>{isGeneratingMission ? '生成中…' : 'サムライミッションを受け取る'}</Text>
              </Pressable>
            )}
          </View>

          <Text style={styles.goalSub}>自分で決める今日のミッション</Text>
          <TextInput
            style={styles.bigInput}
            value={missionInput}
            onChangeText={setMissionInput}
            placeholder="例）YouTubeを1本出す / HIITを10分やる"
            placeholderTextColor="#666"
            multiline
          />

          <Text style={styles.goalSub}>今日のルーティン（タップで追加 or 手入力）</Text>
          <View style={styles.chipRow}>
            {DEFAULT_ROUTINES.map(r => {
              const active = currentRoutineLines.includes(r);
              return (
                <Pressable
                  key={r}
                  style={[styles.routineChip, active && styles.routineChipActive]}
                  onPress={() => handleToggleRoutineChip(r)}
                >
                  <Text style={[styles.routineChipText, active && styles.routineChipTextActive]}>{r}</Text>
                </Pressable>
              );
            })}
          </View>

          <TextInput
            style={[styles.todoInput, { marginTop: 8 }]}
            value={routineText}
            onChangeText={setRoutineText}
            placeholder={'例）\n英語1000語\nHIIT 10分\n瞑想5分'}
            placeholderTextColor="#666"
            multiline
          />

          <Text style={[styles.goalSub, { marginTop: 16 }]}>ToDo（改行で複数入力できる）</Text>
          <TextInput
            style={styles.todoInput}
            value={todoInput}
            onChangeText={setTodoInput}
            placeholder={'例）\nYouTube編集を30分\nレゲエの曲を1曲書く'}
            placeholderTextColor="#666"
            multiline
          />

          <Pressable style={styles.primaryButton} onPress={handleSaveTodayMission}>
            <Text style={styles.primaryButtonText}>今日の目標を保存する</Text>
          </Pressable>

          <Pressable style={[styles.secondaryButton, { marginTop: 8 }]} onPress={handleResetTodayLog}>
            <Text style={styles.secondaryButtonText}>今日の目標・日記をリセット</Text>
          </Pressable>
        </View>
      </ScrollView>
    );
  };

  const renderReviewTab = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
      {onboardingData && (
        <View style={styles.goalCard}>
          <View style={styles.samuraiHeaderTopRow}>
            <Text style={styles.samuraiHeaderTitle}>サムライ宣言</Text>
            <Pressable
              onPress={() => {
                if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
                setIsEditingOnboarding(true);
                setObIdentity(onboardingData.identity ?? '');
                setObQuit(onboardingData.quit ?? '');
                setObRule(onboardingData.rule ?? '');
              }}
              style={styles.samuraiEditButton}
            >
              <Text style={styles.samuraiEditText}>編集</Text>
            </Pressable>
          </View>

          {isEditingOnboarding ? (
            <>
              <Text style={styles.onboardingLabel}>1. どんなサムライで生きたい？</Text>
              <TextInput style={styles.onboardingInput} value={obIdentity} onChangeText={setObIdentity} multiline />
              <Text style={styles.onboardingLabel}>2. やめたい習慣は？</Text>
              <TextInput style={styles.onboardingInput} value={obQuit} onChangeText={setObQuit} multiline />
              <Text style={styles.onboardingLabel}>3. 毎日のマイルール</Text>
              <TextInput style={styles.onboardingInput} value={obRule} onChangeText={setObRule} multiline />

              <View style={{ flexDirection: 'row', marginTop: 8 }}>
                <Pressable style={[styles.onboardingButton, { flex: 1, marginRight: 4 }]} onPress={handleSaveOnboarding}>
                  <Text style={styles.onboardingButtonText}>保存</Text>
                </Pressable>
                <Pressable
                  style={[styles.onboardingButton, { flex: 1, marginLeft: 4, backgroundColor: '#374151' }]}
                  onPress={() => {
                    if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
                    setIsEditingOnboarding(false);
                    setObIdentity(onboardingData.identity ?? '');
                    setObQuit(onboardingData.quit ?? '');
                    setObRule(onboardingData.rule ?? '');
                  }}
                >
                  <Text style={[styles.onboardingButtonText, { color: '#e5e7eb' }]}>キャンセル</Text>
                </Pressable>
              </View>
            </>
          ) : (
            <>
              <Text style={styles.samuraiHeaderLabel}>◆ 俺が目指すサムライ像</Text>
              <Text style={styles.samuraiHeaderText}>{onboardingData.identity || '（未入力）'}</Text>
              <Text style={styles.samuraiHeaderLabel}>◆ やめる習慣</Text>
              <Text style={styles.samuraiHeaderText}>{onboardingData.quit || '（未入力）'}</Text>
              <Text style={styles.samuraiHeaderLabel}>◆ 毎日のルール</Text>
              <Text style={styles.samuraiHeaderText}>{onboardingData.rule || '（未入力）'}</Text>
            </>
          )}
        </View>
      )}

      <View style={styles.goalCard}>
        <Text style={styles.goalTitle}>夜の振り返り</Text>
        <Text style={styles.goalSub}>今日一日を３つの質問で振り返るでござる。</Text>

        <Text style={styles.questionText}>1. 今日、一番誇れる行動はなんだ？</Text>
        <TextInput style={styles.bigInput} value={proudInput} onChangeText={setProudInput} multiline />

        <Text style={styles.questionText}>2. 気づいたこと・学んだことは？</Text>
        <TextInput style={styles.bigInput} value={lessonInput} onChangeText={setLessonInput} multiline />

        <Text style={styles.questionText}>3. 明日ひとつだけ変えてみる行動は？</Text>
        <TextInput style={styles.bigInput} value={nextActionInput} onChangeText={setNextActionInput} multiline />

        <Pressable style={styles.primaryButton} onPress={handleSaveNightReview}>
          <Text style={styles.primaryButtonText}>今日の振り返りを保存する</Text>
        </Pressable>
      </View>

      <View style={styles.goalCard}>
        <Text style={styles.goalTitle}>サムライRPGダッシュボード</Text>
        <Text style={styles.goalSub}>連続ログ：{streakCount} 日でござる🔥</Text>
        <Text style={styles.goalSub}>
          サムライレベル：Lv.{samuraiLevel} / {MAX_LEVEL}{' '}
          {samuraiLevel >= MAX_LEVEL ? '（伝説の侍クリア！）' : `（あと ${daysToClear} 日で伝説の侍）`}
        </Text>

        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${Math.round(levelProgress * 100)}%` }]} />
        </View>
        <Text style={styles.progressHint}>3日続けるごとにレベルアップ。1ヶ月やり切れば伝説クリアでござる。</Text>

        <Text style={styles.goalSub}>
          総経験値：{totalXp} XP（ランク：{rank.label}
          {rank.next > 0 ? ` / 次のランクまで ${rank.next} XP` : ' / MAX'}）
        </Text>

        <SamuraiAvatar level={samuraiLevel} rankLabel={rank.label} />

        <Text style={[styles.goalTitle, { fontSize: 16, marginTop: 6 }]}>サムライ日記カレンダー</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 8, marginBottom: 8 }}>
          {sortedDailyLogs.map(log => {
            const isActive = log.date === activeDate;
            return (
              <Pressable
                key={log.date}
                onPress={() => {
                  if (settings.enableHaptics) Haptics.selectionAsync().catch(() => {});
                  setSelectedDate(log.date);
                }}
                style={[styles.dateChip, isActive && styles.dateChipActive]}
              >
                <Text style={[styles.dateChipText, isActive && styles.dateChipTextActive]}>{formatDateLabel(log.date)}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {activeLog ? (
          <View style={{ marginTop: 8 }}>
            <Text style={styles.historyDate}>{activeLog.date}</Text>

            <Text style={styles.historyLabel}>◆ 目標</Text>
            <Text style={styles.historyText}>{activeLog.mission || '（未入力だぞ）'}</Text>

            <Text style={styles.historyLabel}>◆ サムライミッション</Text>
            <Text style={styles.historyText}>
              {activeLog.samuraiMission
                ? `${activeLog.samuraiMission} ${activeLog.missionCompleted ? '（達成済み）' : '（未達成）'}`
                : '（まだ受け取っていないぞ）'}
            </Text>

            <Text style={styles.historyLabel}>◆ サムライルーティン</Text>
            {activeLog.routines.length === 0 ? (
              <Text style={styles.historyText}>（まだ選ばれていないぞ）</Text>
            ) : (
              activeLog.routines.map(r => {
                const done = activeLog.routineDone?.includes(r);
                return (
                  <Pressable key={r} style={styles.todoRow} onPress={() => toggleRoutineDone(activeLog.date, r)}>
                    <View style={[styles.checkbox, done && styles.checkboxChecked]} />
                    <Text style={[styles.todoText, done && styles.todoTextDone]}>{r}</Text>
                  </Pressable>
                );
              })
            )}

            <Text style={styles.historyLabel}>◆ ToDo</Text>
            {activeLog.todos.length === 0 ? (
              <Text style={styles.historyText}>（登録なしだ）</Text>
            ) : (
              activeLog.todos.map(todo => (
                <Pressable key={todo.id} style={styles.todoRow} onPress={() => toggleTodoDone(activeLog.date, todo.id)}>
                  <View style={[styles.checkbox, todo.done && styles.checkboxChecked]} />
                  <Text style={[styles.todoText, todo.done && styles.todoTextDone]}>{todo.text}</Text>
                </Pressable>
              ))
            )}

            {editingLogDate === activeLog.date ? (
              <>
                <Text style={styles.historyLabel}>◆ 今日一番誇れる行動（編集）</Text>
                <TextInput
                  style={styles.bigInput}
                  multiline
                  value={editProud}
                  onChangeText={setEditProud}
                  placeholder="今日一番誇れる行動を書いてくだされ。"
                  placeholderTextColor="#666"
                />

                <Text style={styles.historyLabel}>◆ 気づき・学び（編集）</Text>
                <TextInput
                  style={styles.bigInput}
                  multiline
                  value={editLesson}
                  onChangeText={setEditLesson}
                  placeholder="気づき・学びを書いてくだされ。"
                  placeholderTextColor="#666"
                />

                <Text style={styles.historyLabel}>◆ 明日変えてみる行動（編集）</Text>
                <TextInput
                  style={styles.bigInput}
                  multiline
                  value={editNextAction}
                  onChangeText={setEditNextAction}
                  placeholder="明日変えてみる行動を書いてくだされ。"
                  placeholderTextColor="#666"
                />

                <View style={styles.historyButtonsRow}>
                  <Pressable style={styles.historyButton} onPress={handleSaveEditedLog}>
                    <Text style={styles.historyButtonText}>保存</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.historyButton, styles.historyDeleteButton]}
                    onPress={() => {
                      setEditingLogDate(null);
                      setEditProud('');
                      setEditLesson('');
                      setEditNextAction('');
                    }}
                  >
                    <Text style={styles.historyButtonText}>キャンセル</Text>
                  </Pressable>
                </View>
              </>
            ) : (
              <>
                <Text style={styles.historyLabel}>◆ 今日一番誇れる行動</Text>
                <Text style={styles.historyText}>{activeLog.review?.proud || '（未入力）'}</Text>

                <Text style={styles.historyLabel}>◆ 気づき・学び</Text>
                <Text style={styles.historyText}>{activeLog.review?.lesson || '（未入力）'}</Text>

                <Text style={styles.historyLabel}>◆ 明日変えてみる行動</Text>
                <Text style={styles.historyText}>{activeLog.review?.nextAction || '（未入力）'}</Text>

                <View style={styles.historyButtonsRow}>
                  <Pressable style={styles.historyButton} onPress={() => handleEditLogFromCalendar(activeLog)}>
                    <Text style={styles.historyButtonText}>編集</Text>
                  </Pressable>
                  <Pressable style={[styles.historyButton, styles.historyDeleteButton]} onPress={() => handleDeleteLog(activeLog.date)}>
                    <Text style={styles.historyButtonText}>削除</Text>
                  </Pressable>
                </View>
              </>
            )}
          </View>
        ) : (
          <Text style={[styles.historyText, { marginTop: 8 }]}>まだサムライ日記はないでござる。</Text>
        )}
      </View>
    </ScrollView>
  );

  const renderBrowserTab = () => {
    const normalizedCurrent = currentUrl.replace(/^https?:\/\//, '').toLowerCase();
    const isBlocked = blockedDomains.some(domain => normalizedCurrent.startsWith(domain));

    return (
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
        <View style={styles.goalCard}>
          <Text style={styles.goalTitle}>サムライブラウザ</Text>
          <Text style={styles.goalSub}>
            禁欲・集中モード用のブラウザでござる。ここでだけネットをする、というマイルールもオススメ。
          </Text>

          <View style={styles.urlRow}>
            <TextInput
              style={styles.urlInput}
              value={browserUrl}
              onChangeText={setBrowserUrl}
              autoCapitalize="none"
              keyboardType="url"
              placeholder="例）twitter.com / youtube.com"
              placeholderTextColor="#666"
            />
            <Pressable style={styles.urlOpenButton} onPress={handleOpenBrowserUrl}>
              <Text style={styles.urlOpenButtonText}>開く</Text>
            </Pressable>
          </View>

          <Text style={styles.browserInfo}>ブロック対象：{blockedDomains.length ? blockedDomains.join(', ') : '（未設定）'}</Text>

          <Text style={[styles.sectionTitle, { marginTop: 10 }]}>ブロックリスト</Text>
          <Text style={styles.goalSub}>見たくないサイト（ドメイン）を登録しておくと、自動でブロックされる。</Text>

          <View style={styles.urlRow}>
            <TextInput
              style={styles.urlInput}
              value={blocklistInput}
              onChangeText={setBlocklistInput}
              autoCapitalize="none"
              placeholder="例）twitter.com"
              placeholderTextColor="#666"
            />
            <Pressable style={styles.urlOpenButton} onPress={handleAddBlockDomain}>
              <Text style={styles.urlOpenButtonText}>追加</Text>
            </Pressable>
          </View>

          {blockedDomains.length > 0 && (
            <View style={{ marginTop: 8 }}>
              {blockedDomains.map(domain => (
                <View key={domain} style={styles.blockRow}>
                  <Text style={styles.blockDomain}>{domain}</Text>
                  <Pressable onPress={() => handleRemoveBlockDomain(domain)}>
                    <Text style={styles.blockRemove}>解除</Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={[styles.browserContainer, { height: 420 }]}>
          {isBlocked ? (
            <View style={styles.blockedCard}>
              <Text style={styles.blockedTitle}>⚔️ そこは罠のサイトだぞ</Text>
              <Text style={styles.blockedText}>
                今アクセスしようとした場所は、お主が「封印」すると決めた領域だ。{'\n'}
                ここで時間やエネルギーを溶かすより、サムライミッションか目標に一手を打とう。
              </Text>

              <Pressable style={styles.blockedButton} onPress={() => setTab('consult')}>
                <Text style={styles.blockedButtonText}>今の気持ちを相談する</Text>
              </Pressable>
            </View>
          ) : (
            <WebView source={{ uri: currentUrl }} style={{ flex: 1 }} />
          )}
        </View>
      </ScrollView>
    );
  };

  const renderSettingsTab = () => (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
      <View style={styles.goalCard}>
        <Text style={styles.goalTitle}>設定</Text>
        <Text style={styles.goalSub}>サムライキングの声やバイブの強さを、自分好みにカスタムできるでござる。</Text>

        <Text style={styles.sectionTitle}>サムライボイス</Text>
        <View style={styles.settingsRow}>
          <View style={styles.settingsRowText}>
            <Text style={styles.settingsLabel}>自動で声を再生する</Text>
            <Text style={styles.settingsHint}>OFFにすると、テキストだけ静かに読むモードになるでござる。</Text>
          </View>
          <Switch value={settings.autoVoice} onValueChange={v => updateSettings({ autoVoice: v })} />
        </View>

        <Text style={[styles.settingsLabel, { marginTop: 8 }]}>読み上げスピード</Text>
        <View style={styles.segmentRow}>
          {[
            { key: 'slow', label: 'ゆっくり' },
            { key: 'normal', label: 'ふつう' },
            { key: 'fast', label: '速め' },
          ].map(opt => {
            const active = settings.readingSpeed === opt.key;
            return (
              <Pressable
                key={opt.key}
                style={[styles.segmentButton, active && styles.segmentButtonActive]}
                onPress={() => updateSettings({ readingSpeed: opt.key as AppSettings['readingSpeed'] })}
              >
                <Text style={[styles.segmentButtonText, active && styles.segmentButtonTextActive]}>{opt.label}</Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={styles.sectionTitle}>フィードバック</Text>
        <View style={styles.settingsRow}>
          <View style={styles.settingsRowText}>
            <Text style={styles.settingsLabel}>バイブ（Haptics）</Text>
            <Text style={styles.settingsHint}>ボタン操作のときに、手応えを少しだけ返すでござる。</Text>
          </View>
          <Switch value={settings.enableHaptics} onValueChange={v => updateSettings({ enableHaptics: v })} />
        </View>
        <View style={styles.settingsRow}>
          <View style={styles.settingsRowText}>
            <Text style={styles.settingsLabel}>効果音</Text>
            <Text style={styles.settingsHint}>ボタンを押したときの太鼓の音などをON/OFFできる。</Text>
          </View>
          <Switch value={settings.enableSfx} onValueChange={v => updateSettings({ enableSfx: v })} />
        </View>

        <Text style={styles.sectionTitle}>サムライキングの厳しさ</Text>
        <View style={styles.segmentRow}>
          {[
            { key: 'soft', label: 'ゆるめ' },
            { key: 'normal', label: 'ふつう' },
            { key: 'hard', label: '鬼コーチ' },
          ].map(opt => {
            const active = settings.strictness === opt.key;
            return (
              <Pressable
                key={opt.key}
                style={[styles.segmentButton, active && styles.segmentButtonActive]}
                onPress={() => updateSettings({ strictness: opt.key as AppSettings['strictness'] })}
              >
                <Text style={[styles.segmentButtonText, active && styles.segmentButtonTextActive]}>{opt.label}</Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={styles.sectionTitle}>サムライタイム（1日の使用時間制限）</Text>
        <Text style={styles.settingsHint}>このアプリを1日に何分まで使うかを決めるでござる。0分なら無制限。</Text>

        <View style={styles.settingsRow}>
          <View style={styles.settingsRowText}>
            <Text style={styles.settingsLabel}>1日の上限（分）</Text>
            <Text style={styles.settingsHint}>例）30なら、今日トータル30分までだけ使える。</Text>
          </View>
          <TextInput
            style={styles.timeInput}
            keyboardType="number-pad"
            value={String(samuraiTime.dailyMinutes ?? 0)}
            onChangeText={updateSamuraiDailyMinutes}
          />
        </View>

        {isTimeLimited && (
          <Text style={styles.settingsHint}>
            今日の使用時間：{usedMinutes} 分 / 上限 {samuraiTime.dailyMinutes} 分{'\n'}
            残り：{remainingMinutes} 分
          </Text>
        )}

        <Text style={styles.sectionTitle}>その他</Text>
        <Pressable style={styles.secondaryButton} onPress={() => setShowPrivacy(true)}>
          <Text style={styles.secondaryButtonText}>プライバシーポリシーを見る</Text>
        </Pressable>
      </View>
    </ScrollView>
  );

  const renderOnboarding = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.appTitle}>BUSHIDO LOG</Text>
      <Text style={styles.onboardingLead}>まずは「どんなサムライとして生きるか」を決めるところから始めよう。</Text>

      <Text style={styles.onboardingLabel}>1. どんなサムライとして生きたい？</Text>
      <TextInput
        style={styles.onboardingInput}
        value={obIdentity}
        onChangeText={setObIdentity}
        multiline
        placeholder="例）家族に優しく、世界で戦うサムライアーティスト"
        placeholderTextColor="#6b7280"
      />

      <Text style={styles.onboardingLabel}>2. やめたい習慣は？</Text>
      <TextInput
        style={styles.onboardingInput}
        value={obQuit}
        onChangeText={setObQuit}
        multiline
        placeholder="例）ダラダラSNS、夜更かし"
        placeholderTextColor="#6b7280"
      />

      <Text style={styles.onboardingLabel}>3. 毎日のマイルール</Text>
      <TextInput
        style={styles.onboardingInput}
        value={obRule}
        onChangeText={setObRule}
        multiline
        placeholder="例）毎日1つは未来のための行動をする"
        placeholderTextColor="#6b7280"
      />

      <Pressable style={styles.primaryButton} onPress={handleSaveOnboarding}>
        <Text style={styles.primaryButtonText}>サムライ宣言を保存して始める</Text>
      </Pressable>
    </View>
  );

  const renderTimeOver = () => (
    <View style={styles.timeOverContainer}>
      <View style={styles.timeOverCard}>
        <Text style={styles.timeOverTitle}>本日のサムライタイム終了</Text>
        <Text style={styles.timeOverText}>
          今日の「BUSHIDO LOG」を使える時間は使い切ったでござる。{'\n'}
          ここから先は、現実世界でサムライミッションを遂行する時間だ。
        </Text>
        <Text style={[styles.timeOverText, { marginTop: 6 }]}>※ 明日になると、時間は自動でリセットされる。</Text>

        <Pressable style={[styles.primaryButton, { marginTop: 12 }]} onPress={() => setTab('settings')}>
          <Text style={styles.primaryButtonText}>サムライタイムの設定を見直す</Text>
        </Pressable>
      </View>
    </View>
  );

  // =========================
  // Loading
  // =========================
  if (isLoadingOnboarding) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#16a34a" />
        <Text style={styles.loadingText}>サムライキングを呼び出し中…</Text>
      </View>
    );
  }

  return (
    <>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={styles.container}>
            <View style={styles.header}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={styles.appTitle}>BUSHIDO LOG</Text>
                {isTimeLimited && (
                  <View style={styles.timeBadge}>
                    <Text style={styles.timeBadgeText}>残り：{remainingMinutes !== null ? `${remainingMinutes}分` : '∞'}</Text>
                  </View>
                )}
              </View>
              <Text style={styles.headerSub}>性エネルギーを創造エネルギーに変えるサムライ習慣アプリ</Text>
            </View>

            {isOnboarding ? (
              renderOnboarding()
            ) : (
              <>
                <View style={styles.tabRow}>
                  {renderTabButton('consult', '相談')}
                  {renderTabButton('goal', '目標')}
                  {renderTabButton('review', '振り返り')}
                  {renderTabButton('browser', 'ブラウザ')}
                  {renderTabButton('settings', '設定')}
                </View>

                <View style={{ flex: 1 }}>
                  {isTimeOver && tab !== 'settings' ? (
                    renderTimeOver()
                  ) : (
                    <>
                      {tab === 'consult' && renderConsultTab()}
                      {tab === 'goal' && renderGoalTab()}
                      {tab === 'review' && renderReviewTab()}
                      {tab === 'browser' && renderBrowserTab()}
                      {tab === 'settings' && renderSettingsTab()}
                    </>
                  )}
                </View>
              </>
            )}
          </View>
      </KeyboardAvoidingView>

      <Modal visible={showPrivacy} animationType="slide" transparent>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>プライバシーポリシー</Text>
            <ScrollView style={{ maxHeight: 400 }}>
              <Text style={styles.modalText}>{PRIVACY_POLICY_TEXT}</Text>
            </ScrollView>
            <Pressable style={[styles.primaryButton, { marginTop: 12 }]} onPress={() => setShowPrivacy(false)}>
              <Text style={styles.primaryButtonText}>閉じる</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

// =========================
// Styles (complete)
// =========================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingTop: 40,
    paddingHorizontal: 12,
  },
  header: {
    marginBottom: 8,
  },
  appTitle: {
    fontSize: 22,
    fontWeight: '900',
    color: '#f97316',
  },
  headerSub: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 2,
  },
  timeBadge: {
    marginLeft: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 999,
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#f97316',
  },
  timeBadgeText: {
    fontSize: 11,
    color: '#f97316',
    fontWeight: '600',
  },
  tabRow: {
    flexDirection: 'row',
    marginBottom: 8,
    borderRadius: 999,
    backgroundColor: '#0f172a',
    padding: 2,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 999,
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#f97316',
  },
  tabButtonText: {
    fontSize: 12,
    color: '#9ca3af',
    fontWeight: '600',
  },
  tabButtonTextActive: {
    color: '#0f172a',
  },

  urgeButton: {
    backgroundColor: '#f97316',
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 4,
  },
  urgeText: {
    color: '#0f172a',
    fontWeight: '800',
  },
  caption: {
    fontSize: 11,
    color: '#9ca3af',
    marginBottom: 8,
  },
  summonBox: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 12,
    backgroundColor: '#020617',
  },
  summonTitle: {
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 4,
  },
  summonText: {
    fontSize: 12,
    color: '#9ca3af',
  },

  modeRow: {
    flexDirection: 'row',
    marginTop: 12,
    marginBottom: 4,
  },
  modeButton: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#1e293b',
    alignItems: 'center',
    marginRight: 4,
  },
  modeButtonActive: {
    backgroundColor: '#0f172a',
  },
  modeButtonText: {
    fontSize: 12,
    color: '#9ca3af',
  },
  modeButtonTextActive: {
    color: '#e5e7eb',
    fontWeight: '700',
  },

  chatBox: {
    flex: 1,
    minHeight: 0,

    marginTop: 8,
    borderRadius: 16,
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    padding: 8,
  },
  chatTitle: {
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 4,
  },
  messages: {
    flex: 1,
    marginBottom: 6,
  },
  bubble: {
    maxWidth: '88%',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 18,
    marginBottom: 6,
  },
  userBubble: {
    backgroundColor: '#0f172a',
    alignSelf: 'flex-end',
  },
  kingBubble: {
    backgroundColor: '#f97316',
    alignSelf: 'flex-start',
  },
  bubbleLabel: {
    fontSize: 10,
    fontWeight: '700',
    marginBottom: 2,
    color: '#020617',
  },
  bubbleText: {
    fontSize: 16,
    lineHeight: 26,
    
    color: '#020617',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    minHeight: 36,
    maxHeight: 80,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#334155',
    paddingHorizontal: 8,
    paddingVertical: 6,
    fontSize: 13,
    color: '#e5e7eb',
    marginRight: 4,
  },
  sendButton: {
    backgroundColor: '#f97316',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendText: {
    color: '#0f172a',
    fontWeight: '700',
    fontSize: 12,
  },
  privacyNote: {
    fontSize: 10,
    color: '#6b7280',
    marginTop: 4,
  },

  secondaryButton: {
    marginTop: 6,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#4b5563',
    alignItems: 'center',
  },
  secondaryButtonText: {
    fontSize: 11,
    color: '#e5e7eb',
  },

  historyInfo: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 4,
  },
  historyEntry: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#1f2937',
    padding: 8,
    marginBottom: 6,
    backgroundColor: '#020617',
  },
  historyDate: {
    fontSize: 11,
    color: '#9ca3af',
    marginBottom: 2,
  },
  historyLabel: {
    fontSize: 11,
    color: '#e5e7eb',
    marginTop: 4,
    fontWeight: '700',
  },
  historyText: {
    fontSize: 12,
    color: '#d1d5db',
  },

  goalCard: {
    borderRadius: 16,
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    padding: 12,
    marginTop: 8,
  },
  goalTitle: {
    fontSize: 16,
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 4,
  },
  goalSub: {
    fontSize: 12,
    color: '#9ca3af',
    marginBottom: 6,
  },
  bigInput: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 10,
    fontSize: 13,
    color: '#e5e7eb',
    minHeight: 56,
    marginTop: 4,
    marginBottom: 8,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 4,
  },
  routineChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#334155',
    marginRight: 4,
    marginBottom: 4,
  },
  routineChipActive: {
    backgroundColor: '#f97316',
    borderColor: '#f97316',
  },
  routineChipText: {
    fontSize: 11,
    color: '#9ca3af',
  },
  routineChipTextActive: {
    color: '#0f172a',
    fontWeight: '700',
  },
  todoInput: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 8,
    fontSize: 13,
    color: '#e5e7eb',
    minHeight: 48,
  },

  primaryButton: {
    marginTop: 10,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: '#22c55e',
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#022c22',
    fontWeight: '800',
    fontSize: 13,
  },

  questionText: {
    fontSize: 13,
    color: '#e5e7eb',
    marginTop: 8,
  },

  progressBar: {
    width: '100%',
    height: 10,
    borderRadius: 999,
    backgroundColor: '#0f172a',
    overflow: 'hidden',
    marginTop: 6,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#f97316',
  },
  progressHint: {
    fontSize: 11,
    color: '#9ca3af',
    marginTop: 4,
  },

  dateChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#374151',
    marginRight: 4,
  },
  dateChipActive: {
    backgroundColor: '#f97316',
    borderColor: '#f97316',
  },
  dateChipText: {
    fontSize: 11,
    color: '#9ca3af',
  },
  dateChipTextActive: {
    color: '#0f172a',
    fontWeight: '700',
  },

  todoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  checkbox: {
    width: 16,
    height: 16,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#6b7280',
    marginRight: 6,
  },
  checkboxChecked: {
    backgroundColor: '#22c55e',
    borderColor: '#22c55e',
  },
  todoText: {
    fontSize: 12,
    color: '#e5e7eb',
  },
  todoTextDone: {
    color: '#9ca3af',
    textDecorationLine: 'line-through',
  },

  historyButtonsRow: {
    flexDirection: 'row',
    marginTop: 8,
  },
  historyButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#1f2937',
    alignItems: 'center',
    marginRight: 4,
  },
  historyDeleteButton: {
    backgroundColor: '#7f1d1d',
    marginLeft: 4,
    marginRight: 0,
  },
  historyButtonText: {
    fontSize: 12,
    color: '#e5e7eb',
    fontWeight: '600',
  },

  avatarCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 10,
    marginTop: 8,
  },
  avatarCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#0f172a',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  avatarEmoji: {
    fontSize: 28,
  },
  avatarInfo: {
    flex: 1,
  },
  avatarTitle: {
    fontSize: 14,
    color: '#e5e7eb',
    fontWeight: '700',
  },
  avatarRank: {
    fontSize: 12,
    color: '#f97316',
    marginTop: 2,
  },
  avatarDesc: {
    fontSize: 11,
    color: '#9ca3af',
    marginTop: 2,
  },

  samuraiMissionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  samuraiMissionTitle: {
    fontSize: 14,
    color: '#e5e7eb',
    fontWeight: '700',
  },
  samuraiMissionXp: {
    fontSize: 11,
    color: '#facc15',
    fontWeight: '600',
  },
  samuraiMissionBox: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 10,
    marginTop: 4,
  },
  samuraiMissionText: {
    fontSize: 13,
    color: '#e5e7eb',
    marginBottom: 8,
  },
  samuraiMissionButton: {
    marginTop: 6,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#16a34a',
    alignItems: 'center',
  },
  samuraiMissionButtonText: {
    fontSize: 12,
    color: '#022c22',
    fontWeight: '700',
  },

  samuraiHeaderTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  samuraiHeaderTitle: {
    fontSize: 16,
    color: '#e5e7eb',
    fontWeight: '700',
  },
  samuraiEditButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#4b5563',
  },
  samuraiEditText: {
    fontSize: 11,
    color: '#e5e7eb',
  },

  onboardingLabel: {
    fontSize: 12,
    color: '#e5e7eb',
    marginTop: 8,
    marginBottom: 2,
  },
  onboardingInput: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 8,
    fontSize: 13,
    color: '#e5e7eb',
    minHeight: 48,
  },
  onboardingButton: {
    marginTop: 8,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#22c55e',
    alignItems: 'center',
  },
  onboardingButtonText: {
    fontSize: 13,
    color: '#022c22',
    fontWeight: '700',
  },
  samuraiHeaderLabel: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: 6,
  },
  samuraiHeaderText: {
    fontSize: 13,
    color: '#e5e7eb',
    marginTop: 2,
  },

  urlRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  urlInput: {
    flex: 1,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#334155',
    paddingHorizontal: 8,
    paddingVertical: 6,
    fontSize: 13,
    color: '#e5e7eb',
    marginRight: 4,
  },
  urlOpenButton: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#f97316',
    alignItems: 'center',
  },
  urlOpenButtonText: {
    fontSize: 12,
    color: '#0f172a',
    fontWeight: '700',
  },
  browserInfo: {
    fontSize: 11,
    color: '#9ca3af',
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 14,
    color: '#e5e7eb',
    fontWeight: '700',
    marginTop: 10,
  },

  blockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  blockDomain: {
    fontSize: 12,
    color: '#e5e7eb',
  },
  blockRemove: {
    fontSize: 11,
    color: '#f97316',
  },

  browserContainer: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#1f2937',
    marginTop: 8,
    overflow: 'hidden',
    backgroundColor: '#020617',
  },

  blockedCard: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  blockedTitle: {
    fontSize: 16,
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 8,
  },
  blockedText: {
    fontSize: 13,
    color: '#d1d5db',
  },
  blockedButton: {
    marginTop: 12,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: '#f97316',
    alignItems: 'center',
  },
  blockedButtonText: {
    fontSize: 13,
    color: '#0f172a',
    fontWeight: '700',
  },

  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  settingsRowText: {
    flex: 1,
    marginRight: 8,
  },
  settingsLabel: {
    fontSize: 13,
    color: '#e5e7eb',
    fontWeight: '600',
  },
  settingsHint: {
    fontSize: 11,
    color: '#9ca3af',
    marginTop: 2,
  },

  segmentRow: {
    flexDirection: 'row',
    marginTop: 6,
  },
  segmentButton: {
    flex: 1,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#374151',
    paddingVertical: 6,
    alignItems: 'center',
    marginRight: 4,
  },
  segmentButtonActive: {
    backgroundColor: '#f97316',
    borderColor: '#f97316',
  },
  segmentButtonText: {
    fontSize: 12,
    color: '#9ca3af',
  },
  segmentButtonTextActive: {
    color: '#0f172a',
    fontWeight: '700',
  },

  timeInput: {
    width: 60,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#334155',
    paddingHorizontal: 6,
    paddingVertical: 4,
    fontSize: 13,
    color: '#e5e7eb',
    textAlign: 'center',
  },

  onboardingContainer: {
    flex: 1,
    justifyContent: 'flex-start',
    paddingTop: 12,
  },
  onboardingLead: {
    fontSize: 13,
    color: '#d1d5db',
    marginTop: 4,
    marginBottom: 8,
  },

  loadingContainer: {
    flex: 1,
    backgroundColor: '#020617',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 8,
    fontSize: 13,
    color: '#e5e7eb',
  },

  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  modalCard: {
    width: '100%',
    maxHeight: '80%',
    backgroundColor: '#020617',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
    padding: 14,
  },
  modalTitle: {
    fontSize: 16,
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 6,
  },
  modalText: {
    fontSize: 12,
    color: '#d1d5db',
  },

  timeOverContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timeOverCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#4b5563',
    padding: 16,
    backgroundColor: '#020617',
    width: '100%',
  },
  timeOverTitle: {
    fontSize: 16,
    color: '#e5e7eb',
    fontWeight: '700',
    marginBottom: 8,
  },
  timeOverText: {
    fontSize: 13,
    color: '#d1d5db',
  },
});