// src/constants/keys.ts

export const STORAGE_KEYS = {
  CHAT_HISTORY: 'chat_history',
  DAILY_LOG: 'daily_log',
  SETTINGS: 'settings',
};